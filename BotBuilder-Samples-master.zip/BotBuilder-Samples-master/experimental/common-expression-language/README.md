# Adaptive Expressions (**Stable release**)

This feature is no longer experimental. It is available in **Stable release**, starting botbuilder SDK version 4.9.0 and higher.

| Language     | Availability          | Docs         |
|--------------|-----------------------|--------------|
| csharp       | Generally available   | [here][1]    |
| javascript   | Generally available   | [here][1]    |
| python       | Not available         | N/A          |
| java         | Not available         | N/A          |
 
[1]:https://aka.ms/adaptive-expressions
 
 